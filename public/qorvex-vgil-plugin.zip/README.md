# QORVEX VGIL Enterprise AI Connector Plugin Package

This archive contains the official distribution package for the **QORVEX VGIL Enterprise AI Connector**, ready for upload to OpenAI Plugin Creator and ChatGPT App Directory.

## Package Structure
- `plugin.json`: Agent Plugins 1.0.0 manifest with `extensions.com.openai` presentation and review metadata.
- `mcp.json`: Agent Plugins 1.0.0 Model Context Protocol configuration pointing to the production Streamable HTTP endpoint.
- `skills/vgil-assistant/SKILL.md`: Standardized workflow and grounding instructions.
- `assets/`: 512x512 and 128x128 icons (PNG + SVG).
- `.well-known/ai-plugin.json`: OpenAI classic plugin manifest.
- `.codex-plugin/plugin.json`: Codex-compatible plugin manifest alias.
- `openapi.json`: OpenAPI 3.1 specification.

## Production Endpoints
- **Railway MCP Endpoint**: `https://qorvex-vgil-backend-production.up.railway.app/mcp`
- **OpenAPI Schema**: `https://qorvex-vgil-backend-production.up.railway.app/api/openapi.json`
- **Privacy Policy**: `https://public-nine-alpha-61.vercel.app/privacy.html`
- **Terms of Service**: `https://public-nine-alpha-61.vercel.app/terms.html`
- **Source Repository**: `https://github.com/DataBuks11/QORVEX_VGIL_SyncAI_MCP_MVP`
