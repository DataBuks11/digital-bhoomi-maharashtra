# QORVEX VGIL Knowledge Connector Plugin Package

This archive contains the official distribution package for the **QORVEX VGIL Knowledge Connector**, ready for upload to the OpenAI Plugin Creator, Codex extensions, and ChatGPT App Directory.

## Legal Disclaimer & Non-Endorsement Notice
**QORVEX is an independent, community-developed AI connector.** It provides grounded access to publicly available information from the published web documentation of Virtual Galaxy Infotech Limited (VGIL). QORVEX is **not** officially affiliated with, sponsored by, or endorsed by Virtual Galaxy Infotech Limited.

## Package Structure
- `plugin.json`: Agent Plugins 1.0.0 manifest with `extensions.com.openai` presentation and review metadata.
- `mcp.json`: Agent Plugins 1.0.0 Model Context Protocol configuration pointing to the production Streamable HTTP endpoint.
- `skills/vgil-assistant/SKILL.md`: Standardized workflow and grounding instructions.
- `assets/`: 512x512 and 128x128 icons (PNG + SVG).
- `logo.png`: Root icon alias for legacy uploaders.
- `.well-known/ai-plugin.json` & `ai-plugin.json`: OpenAI classic plugin manifest configured with Bearer HTTP authentication.
- `.codex-plugin/plugin.json`: Codex-compatible plugin manifest alias.
- `openapi.json` & `openapi.yaml`: OpenAPI 3.1 specification declaring BearerAuth security scheme and `/mcp` endpoint.

## Authentication
The Railway MCP endpoint enforces **Bearer token authentication**. In the OpenAI Plugin Creator / platform, configure:
- **Authentication Type**: Bearer / Service HTTP
- **Token**: Your configured `MCP_API_KEY`

## Production Endpoints
- **Railway MCP Endpoint**: `https://qorvex-vgil-backend-production.up.railway.app/mcp`
- **OpenAPI Schema**: `https://qorvex-vgil-backend-production.up.railway.app/api/openapi.json`
- **Privacy Policy**: `https://public-nine-alpha-61.vercel.app/privacy.html`
- **Terms of Service**: `https://public-nine-alpha-61.vercel.app/terms.html`
- **Source Repository**: `https://github.com/DataBuks11/QORVEX_VGIL_SyncAI_MCP_MVP`
