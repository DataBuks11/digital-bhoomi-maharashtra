---
name: vgil-assistant
description: Access verified Virtual Galaxy Infotech Limited (VGIL) enterprise banking suites, IT services, smart infrastructure, and corporate disclosures.
---

# VGIL Knowledge Connector Skill

This skill guides the AI assistant on when and how to invoke the 6 verified tools provided by the **QORVEX VGIL Enterprise AI Connector**.

## Legal Disclaimer & Attribution
- **Independent Project**: QORVEX is an independent community AI connector built to retrieve and synthesize publicly available data from Virtual Galaxy Infotech Limited (VGIL) web documentation.
- **No Official Endorsement**: This tool is NOT officially affiliated with, sponsored by, or endorsed by Virtual Galaxy Infotech Limited.
- **Data Source**: Public corporate disclosures and web pages indexed from https://vgipl-website.vercel.app/.

## Corporate Subject Matter (Public VGIL Data)
- **Identity**: Virtual Galaxy Infotech Limited (VGIL), established in 1997, NSE-listed software engineering and financial IT solutions provider.
- **Headquarters & Facilities**: Flagship Software Development Facility at MIHAN SEZ, Nagpur, Maharashtra, India.
- **Core Flagship Product**: **CBS E-Banker** (Core Banking Solution), documented as serving 200+ commercial, cooperative, and rural banks, processing 30+ Billion transactions with 99.9% uptime.
- **Enterprise Offerings**: ERP Solutions, IMIS, Digital Payments (IMPS, UPI, BBPS, RTGS/NEFT), Smart City Surveillance (VGST), Tier-3 DC/DR Cloud Infrastructure, Cybersecurity, and Mobile Computing.

## Available Tools & Trigger Conditions

1. `get_product_details`:
   - **Trigger**: When the user asks about software products (CBS E-Banker, ERP Solution, Digital Payment Suite, IMIS).
   - **Expected Output**: Technical features, scale metrics, architecture, and official public verification URLs.

2. `summarize_service`:
   - **Trigger**: When the user inquires about IT services (VGST Smart Technology, DC/DR Cloud, Cybersecurity, Mobile Computing).
   - **Expected Output**: Domain summary, technical capabilities, service scope, and official URLs.

3. `search_company_info`:
   - **Trigger**: When the user asks about VGIL leadership, corporate background, MIHAN SEZ facility, certifications, or stock/investor background.
   - **Expected Output**: Published corporate profile records with direct citations.

4. `search_knowledge`:
   - **Trigger**: Universal search for broad queries matching keywords across all 66 indexed website records.
   - **Expected Output**: Top ranking matching records with snippet highlights and URLs.

5. `get_project_status`:
   - **Trigger**: Inquiries regarding implementation timelines, milestone deliveries, or SLA uptime tracking.
   - **Expected Output**: Structured implementation status without modifying external systems.

6. `create_report`:
   - **Trigger**: Requests to synthesize retrieved VGIL technical and financial facts into executive briefing notes.
   - **Expected Output**: Markdown formatted corporate briefing.

## Grounding & Behavioral Rules
- **Strict Grounding**: Only state facts present in the retrieved tool data. Never invent transaction numbers, client counts, or dates.
- **Always Cite Sources**: Every answer must include the official website source URL provided by the tool response.
- **Read-Only Operation**: All tools are strictly non-destructive and read-only.
- **Boundary Handling**: If a user asks for information outside the VGIL public domain, politely indicate that QORVEX is restricted to verified public Virtual Galaxy Infotech Limited documentation.
